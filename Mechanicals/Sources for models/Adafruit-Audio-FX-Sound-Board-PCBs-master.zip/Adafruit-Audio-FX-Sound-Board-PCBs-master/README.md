# Adafruit-Audio-FX-Sound-Boards
PCB files for the Adafruit Audio FX Sound Boards

Format is EagleCAD schematic and board layout

For more details, check out the product pages at

   * https://www.adafruit.com/products/2133
   * https://www.adafruit.com/products/2220
   * https://www.adafruit.com/products/2341
   * https://www.adafruit.com/products/2342
   * https://www.adafruit.com/products/2210
   * https://www.adafruit.com/products/2217

Adafruit invests time and resources providing this open source design, 
please support Adafruit and open-source hardware by purchasing 
products from Adafruit!

Designed by Adafruit Industries.  
Creative Commons Attribution, Share-Alike license, check license.txt for more information
All text above must be included in any redistribution